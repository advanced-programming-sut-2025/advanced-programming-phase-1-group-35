package Controller;

import Model.Result;
import Model.Tools.FishingPole;

public class GameMenuController {
    public Result createNewGame(String username1, String username2, String username3) {
        return null;
    }

    private boolean isUserInOtherGame(String username) {
        return false;
    }

    public Result chooseMap() {
        return null;
    }

    public Result loadGame() {
        return null;
    }

    public Result saveGame() {
        return null;
    }

    public Result exitGame() {
        return null;
    }

    public Result deleteCurrentGame() {
        return null;
    }

    public void goToNextTurn() {

    }

    public Result showTime() {
        return null;
    }

    public Result showDate() {
        return null;
    }

    public Result showTimeAndDate() {
        return null;
    }

    public Result showDayOfTheWeek() {
        return null;
    }

    public Result showSeason() {
        return null;
    }

    public Result showWeather() {
        return null;
    }

    public Result showWeatherForecast() {
        return null;
    }

    public void goToNextDay() {

    }

    public void walk(int x, int y) {

    }

    private boolean isThereAnyWayToGetToTheDestination() {
        return false;
    }

    private void findTheBestWayToGetToTheDestination() {

    }

    public Result printMap() {
        return null;
    }

    public Result helpReadingTheMap() {
        return null;
    }

    public Result showEnergy() {
        return null;
    }

    public Result showInventory() {
        return null;
    }

    public Result deleteAnItemFromInventory() {
        return null;
    }

    public Result buyAnimal(String animalType ,String animalName) {
        return null;
    }
    public String petAnimal(String animalName){
        return null;
    }
    public String AnimalsDetails(){
        return null;
    }
    public Result shepherdAnimal(String animalName){
        return null;
    }
    public Result feedHay(String animalName){
        return null;
    }
    public String produces(){
        return null;
    }
    public Result collectProducts(String animalName){
        return null;
    }
    public Result sellAnimal(String animalName){
        return null;
    }
    public Result fishing(FishingPole fishingPole){
        return null;
    }
    public Result useArtisan(String ArtisanName , String productName){
        return null;
    }
    public Result getFromArtisan(String ArtisanName){
        return null;
    }
    public void talk (){

    }
    public void talkHistory(){

    }
    public Result hug(){
        return null;
    }
    public Result flower(){
        return null;
    }
    public Result askMarriage(){
        return null;
    }
    public Result respondToMarriageRequest(){
        return null;
    }
    public void goToTradeMenu(){

    }
    public Result meetNPC(){
        return null;
    }
    public void npcFriendshipList(){

    }
    public void questList(){

    }
    public Result completeQuest(){
        return null;
    }
    public Result Sell(){
        return null;
    }

}
