package Controller.InGameMenu;

import Model.Result;

public class TradeAndGiftMenu {
    public void listTradeRequests(){

    }
    public Result respondToTrade(){
        return null;
    }
    public void tradeHistory(){

    }
    public Result giftNPC(){
        return null;
    }
    public Result gift (){
        return null;
    }
    public Result RateGift(){
        return null;
    }
    public void showGiftList(){

    }
}
