package Controller.InGameMenu;

import Model.Result;

import Model.Shops.Shop;

public class ShopMenu {
    Shop shop;
    ShopMenu(Shop shop) {
        this.shop = shop;
    }

    public void showAllProducts() {

    }
    public void showAvailableProducts() {

    }
    public Result purchase(){
        return null;
    }

    public Result CheatAdd(){
        return null;
    }
}
