package View;

import java.io.IOException;
import java.util.Scanner;

public interface AppMenu {
    public abstract void check(Scanner scanner) throws IOException;
}
