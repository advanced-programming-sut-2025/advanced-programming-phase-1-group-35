package View.InGameMenu;

import View.AppMenu;

import java.util.Scanner;

public class TradeMenu implements AppMenu {
    public void check(Scanner scanner){}
}
