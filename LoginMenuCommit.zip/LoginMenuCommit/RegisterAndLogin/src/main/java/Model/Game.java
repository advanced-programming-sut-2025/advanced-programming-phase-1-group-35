package Model;

import java.util.ArrayList;

public class Game {
    private ArrayList<User> players;
    private User playingUser;
    private GameCalender gameCalender;
    private Weather weather;
    private ArrayList<Map> maps;


    public void makeRandomMaps() {

    }

}
