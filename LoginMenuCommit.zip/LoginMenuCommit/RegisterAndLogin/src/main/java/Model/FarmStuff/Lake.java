package Model.FarmStuff;

public class Lake extends Farm {
}
