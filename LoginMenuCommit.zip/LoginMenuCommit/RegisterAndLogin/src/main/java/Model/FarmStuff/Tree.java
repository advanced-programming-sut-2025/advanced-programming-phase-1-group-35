package Model.FarmStuff;

public class Tree {
}
