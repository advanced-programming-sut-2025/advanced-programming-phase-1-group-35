package Model.FarmStuff;

public class Foraging {
}
