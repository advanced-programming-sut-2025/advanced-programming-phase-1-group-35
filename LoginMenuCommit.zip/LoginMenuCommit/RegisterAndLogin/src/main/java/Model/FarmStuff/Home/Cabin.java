package Model.FarmStuff.Home;
public class Cabin extends Model.FarmStuff.Farm {

}
