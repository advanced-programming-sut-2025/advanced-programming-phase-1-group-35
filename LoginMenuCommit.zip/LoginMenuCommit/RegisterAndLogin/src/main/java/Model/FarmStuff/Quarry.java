package Model.FarmStuff;

public class Quarry extends Farm {
}
