package Model.enums;

public enum Seasons {
    Spring, Summer, Fall, Winter;
}
