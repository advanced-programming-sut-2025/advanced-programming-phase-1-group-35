package Model.enums;

public enum TileContents {
    rock,
    tree,
    foraging;
}
