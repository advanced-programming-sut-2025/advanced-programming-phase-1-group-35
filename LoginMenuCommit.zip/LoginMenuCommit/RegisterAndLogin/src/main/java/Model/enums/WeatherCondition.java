package Model.enums;

public enum WeatherCondition {
    sunny,
    rain,
    storm,
    snow;
}
