package Model.enums.Commands;

public enum FarmingCommands {
}
