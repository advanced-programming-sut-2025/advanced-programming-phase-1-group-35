package Model.enums.Crops;

public enum Seed {
    //to be added
    ;
    boolean isMixed;
    boolean isForaging;

}
