package Model.enums.NPCs;

public enum NPCDialogues {
}
