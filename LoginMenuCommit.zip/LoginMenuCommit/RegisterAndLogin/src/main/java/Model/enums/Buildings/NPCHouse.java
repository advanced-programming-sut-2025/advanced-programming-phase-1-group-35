package Model.enums.Buildings;

public enum NPCHouse {
}
