package Model.enums;

public enum Gender {
    male,
    female;
}
