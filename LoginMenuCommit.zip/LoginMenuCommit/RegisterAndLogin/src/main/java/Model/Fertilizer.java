package Model;

public class Fertilizer extends Item{
}
