package Model;

public class Food {
}
