package Model.NPCs;

public class NPC {
    public String name ;
    public Quest[] quests;
    public String job;
}
