package Model;

import Model.enums.WeatherCondition;

public class Weather {
    private WeatherCondition weatherCondition;

    public void applySunnyWeather() {

    }

    public void applyRainWeather() {

    }

    public void applySnowWeather() {

    }

    public void applyStormWeather() {

    }

    public void applyLightning() {

    }
}
