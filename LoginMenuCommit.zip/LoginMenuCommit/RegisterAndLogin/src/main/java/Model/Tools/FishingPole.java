package Model.Tools;

public class FishingPole extends Tool {

    @Override
    public void reduceEnergy() {

    }
}
