package Model.Tools;

public class WateringCan extends Tool {

    @Override
    public void reduceEnergy() {

    }
}
