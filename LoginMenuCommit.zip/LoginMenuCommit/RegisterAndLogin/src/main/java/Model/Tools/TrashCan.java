package Model.Tools;

public class TrashCan extends Tool {


    public void deleteItem() {
        
    }

    @Override
    public void reduceEnergy() {

    }
}
