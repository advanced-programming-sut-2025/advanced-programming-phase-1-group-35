package Model;

import Model.enums.TileContents;

import java.util.ArrayList;

public class Tile {
    private Coordination coordination;
    private ArrayList<TileContents> contents;


    public void changeTileContents() {

    }

}
