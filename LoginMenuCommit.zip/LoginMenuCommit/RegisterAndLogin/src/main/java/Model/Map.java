package Model;

import java.util.ArrayList;

public class Map {
    private ArrayList<Model.FarmStuff.Farm> farms;
    public ArrayList<Model.Buildings.Building> buildings;
    public ArrayList<Model.Shops.Shop> shops;

}
