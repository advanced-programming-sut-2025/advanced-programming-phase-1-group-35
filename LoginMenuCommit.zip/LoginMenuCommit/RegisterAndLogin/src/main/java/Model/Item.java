package Model;

public class Item {
    public String name;
}
