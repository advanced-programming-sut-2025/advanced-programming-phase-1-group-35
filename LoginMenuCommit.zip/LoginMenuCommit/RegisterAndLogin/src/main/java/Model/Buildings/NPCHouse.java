package Model.Buildings;

public class NPCHouse {
}
