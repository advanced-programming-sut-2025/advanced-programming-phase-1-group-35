package Model.Buildings;

import Model.Buildings.Building;

public class FarmBuilding extends Building {

}
