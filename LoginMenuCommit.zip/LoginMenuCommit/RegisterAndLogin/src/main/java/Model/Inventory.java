package Model;

import Model.Tools.BackPack;

import java.util.ArrayList;

public class Inventory {
    private ArrayList<Item> items;
    private BackPack backPack;

    public void addItem(Item item) {

    }

    public void removeItem(Item item) {

    }
}
