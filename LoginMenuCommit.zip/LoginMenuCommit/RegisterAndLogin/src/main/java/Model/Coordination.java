//Rogue flashbacks , or PTSD.

package Model;

public class Coordination {
    public int x;
    public int y;
    public Coordination(int x, int y) {
        this.x = x;
        this.y = y;
    }
    public boolean isItCloseEnough(Coordination other) {
        return false;
    }
}
