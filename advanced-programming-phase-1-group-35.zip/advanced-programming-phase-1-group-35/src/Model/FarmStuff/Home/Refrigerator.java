package Model.FarmStuff.Home;

public class Refrigerator {
}
