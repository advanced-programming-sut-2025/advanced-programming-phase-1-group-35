package Model.FarmStuff;

public class Greenhouse extends Farm {
    private int rows;
    private int cols;
}
