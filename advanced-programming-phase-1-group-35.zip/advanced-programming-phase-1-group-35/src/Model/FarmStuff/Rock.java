package Model.FarmStuff;

public class Rock {
}
