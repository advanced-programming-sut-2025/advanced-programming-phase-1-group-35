package Model.Shops;

public class BlackSmith extends Shop {

    // TODO : tool upgrades

    @Override
    public void showProducts(){
        super.showProducts();
    }
}
