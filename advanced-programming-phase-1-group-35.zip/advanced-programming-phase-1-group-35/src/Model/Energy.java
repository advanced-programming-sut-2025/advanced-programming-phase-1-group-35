package Model;

public class Energy {
    private int energyAmount;
    private int maxEnergy;


    public void updateEnergyAfterADayPassed() {

    }

    public void checkEnergyWithMaxAmount() {

    }

    public void faint() {

    }
}
