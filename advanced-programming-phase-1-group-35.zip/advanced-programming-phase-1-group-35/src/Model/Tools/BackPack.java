package Model.Tools;

public class BackPack extends Tool {
    private int capacity;



    public void setCapacity(int capacity) {
        this.capacity = capacity;
    }
    public int getCapacity() {
        return capacity;
    }
    @Override
    public void reduceEnergy() {

    }
}
