package Model.Tools;

public class FishingPole extends Model.Tools.Tool {

    @Override
    public void reduceEnergy() {

    }
}
