package Model.Buildings;

public class AnimalHouse extends Model.Buildings.FarmBuilding {
    private String type ;
    private String level;

    public String getType() {
        return type;
    }

    public String getLevel() {
        return level;
    }
}
