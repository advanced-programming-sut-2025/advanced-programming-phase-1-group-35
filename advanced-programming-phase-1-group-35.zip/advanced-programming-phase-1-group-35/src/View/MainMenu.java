package View;

import java.util.Scanner;

public class MainMenu implements AppMenu {
    @Override
    public void check(Scanner scanner) {

    }
}
