package View.InGameMenu;

public class CookingMenu {
}
