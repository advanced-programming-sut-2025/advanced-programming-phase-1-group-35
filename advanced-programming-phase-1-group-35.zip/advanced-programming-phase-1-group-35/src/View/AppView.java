package View;

public class AppView {
    public void run() {}
}
