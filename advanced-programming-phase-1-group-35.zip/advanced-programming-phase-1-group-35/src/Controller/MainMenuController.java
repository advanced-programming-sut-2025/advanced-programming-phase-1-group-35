package Controller;

import Model.enums.Menu;
import Model.Result;

public class MainMenuController {
    public Result showCurrentMenu() {
        return null;
    }

    public Result logout() {
        return null;
    }

    public Result goToMenu(Menu menu) {
        return null;
    }

    public Result exitMenu(Menu menu) {
        return null;
    }
}
