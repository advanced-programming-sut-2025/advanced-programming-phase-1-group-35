package Controller;

import Model.Result;

import java.security.PublicKey;

public class ProfileMenuController {
    public Result showUserInfo() {
        return null;
    }

    public Result changeUsername(String username) {
        return null;
    }

    public Result changePassword(String oldPassword, String newPassword) {
        return null;
    }

    public Result changeNickname(String nickname) {
        return null;
    }

    public Result changeEmail(String email) {
        return null;
    }
}
