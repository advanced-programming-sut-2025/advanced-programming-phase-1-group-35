package Controller;

import Model.Result;

public class LoginMenuController {
    public Result registerUser(String username, String password,
                               String confirmPassword, String email,
                               String nickname, String gender) {
        return null;
    }

    public Result generateRandomPassword() {
        return null;
    }

    public Result login(String username, String password, boolean stayLoggedIn) {
        return null;
    }

    public Result forgotPassword(String username, String answerOfSecurityQuestion) {
        return null;
    }




}
