package Controller.InGameMenu;

import Model.Result;

public class TradeAndGiftMenu {
    public void listTradeRequests(){

    }
    public Result respondToTrade(){

    }
    public void tradeHistory(){

    }
    public Result giftNPC(){

    }
    public Result gift (){

    }
    public Result RateGift(){

    }
    public void showGiftList(){

    }
}
