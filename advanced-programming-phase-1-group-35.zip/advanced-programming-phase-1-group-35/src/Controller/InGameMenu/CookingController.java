package Controller.InGameMenu;

import Model.Food;
import Model.enums.CookingRecipes;

import java.util.List;

public class CookingController {

    private void placeItemInFridge(String ItemName){}
    private void pickItemFromFridge(String ItemName){}
    private List<CookingRecipes> cookingRecipes(){return null;}
    private void addCookingRecipe(CookingRecipes recipe){}
    private Food cook(Food food){return null;}
    private boolean doesInventoryHaveSpace(){return true;}
    private boolean isRecipeLearned(CookingRecipes recipe){return true;}

}
