package Controller.InGameMenu;

import Model.Tile;
import Model.Item;
import Model.enums.CraftingRecipes;

import java.util.List;

public class CraftingController {
    private List<CraftingRecipes> showRecepies(){return null;}
    private Item craftItem(String itemName){return null;}
    public void addRecipe(CraftingRecipes recipe){}
    public boolean doesInventoryHasSpace(){return true;}
    public void placeItem(String ItemName, Tile tile){}
    public Item findItemWithName(String ItemName){return null;}
    public void addItemToInventory(String ItemName){}

}
