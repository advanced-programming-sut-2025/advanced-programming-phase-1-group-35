package Controller;

import Model.Result;
import Model.Tools.FishingPole;

public class GameMenuController {
    public Result createNewGame(String username1, String username2, String username3) {
        return null;
    }

    private boolean isUserInOtherGame(String username) {
        return false;
    }

    public Result chooseMap() {
        return null;
    }

    public Result loadGame() {
        return null;
    }

    public Result saveGame() {
        return null;
    }

    public Result exitGame() {
        return null;
    }

    public Result deleteCurrentGame() {
        return null;
    }

    public void goToNextTurn() {

    }

    public Result showTime() {
        return null;
    }

    public Result showDate() {
        return null;
    }

    public Result showTimeAndDate() {
        return null;
    }

    public Result showDayOfTheWeek() {
        return null;
    }

    public Result showSeason() {
        return null;
    }

    public Result showWeather() {
        return null;
    }

    public Result showWeatherForecast() {
        return null;
    }

    public void goToNextDay() {

    }

    public void walk(int x, int y) {

    }

    private boolean isThereAnyWayToGetToTheDestination() {
        return false;
    }

    private void findTheBestWayToGetToTheDestination() {

    }

    public Result printMap() {
        return null;
    }

    public Result helpReadingTheMap() {
        return null;
    }

    public Result showEnergy() {
        return null;
    }

    public Result showInventory() {
        return null;
    }

    public Result deleteAnItemFromInventory() {
        return null;
    }

    public boolean buyAnimal(String animalType ,String animalName) {

    }
    public String petAnimal(String animalName){

    }
    public String AnimalsDetails(){

    }
    public Result shepherdAnimal(String animalName){

    }
    public Result feedHay(String animalName){

    }
    public String produces(){

    }
    public Result collectProducts(String animalName){

    }
    public Result sellAnimal(String animalName){

    }
    public Result fishing(FishingPole fishingPole){

    }
    public Result useArtisan(String ArtisanName , String productName){

    }
    public Result getFromArtisan(String ArtisanName){

    }
    public void talk (){

    }
    public void talkHistory(){

    }
    public Result hug(){

    }
    public Result flower(){

    }
    public Result askMarriage(){

    }
    public Result respondToMarriageRequest(){

    }
    public void goToTradeMenu(){

    }
    public Result meetNPC(){

    }
    public void npcFriendshipList(){

    }
    public void questList(){

    }
    public Result completeQuest(){

    }
    public Result Sell(){

    }

}
